/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.urv.imas.agent;

/**
 *
 * @author johannesheidecke
 */
public class HarvesterCoordinatorAgent extends ImasAgent {
    
    public HarvesterCoordinatorAgent() {
        super(AgentType.HARVESTER_COORDINATOR);
    }
    
}
